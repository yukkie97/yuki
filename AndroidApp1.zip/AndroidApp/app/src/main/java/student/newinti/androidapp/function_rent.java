package student.newinti.androidapp;


import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class function_rent extends AppCompatActivity {

    SQLiteOpenHelper database;
    SQLiteDatabase db;
    Button btnRent, btnViewRent;
    EditText txtDimen, txtPrice,txtNote;
    TextView txtReporter;
    Spinner storage_type, storage_feature;


    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent);

        database = new DatabaseHelper(this);

        storage_type = (Spinner) findViewById(R.id.storage_type);
        storage_feature = (Spinner) findViewById(R.id.storage_feature);
        txtDimen = (EditText)findViewById(R.id.txtDimen);
        txtPrice = (EditText)findViewById(R.id.txtPrice);
        txtNote = (EditText) findViewById(R.id.txtNote);
        txtReporter = (TextView) findViewById(R.id.txtReporter);
        btnRent = (Button)findViewById(R.id.btnRent);
        btnViewRent = (Button)findViewById(R.id.btnViewRent);


        btnRent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db = database.getWritableDatabase();
                String str_type = storage_type.getSelectedItem().toString();
                String str_feature = storage_feature.getSelectedItem().toString();
                String dimen = txtDimen.getText().toString();
                String price = txtPrice.getText().toString();
                String note = txtNote.getText().toString();

                if (dimen.matches("") && price.matches("") && note.matches("")) {
                    Toast.makeText(getApplicationContext(), "Please Enter All Fields To Rent", Toast.LENGTH_LONG).show();
                } else {
                    insert(str_type, dimen, str_feature, price, note);
                    Toast.makeText(getApplicationContext(), "Rented Successfully", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnViewRent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(function_rent.this, function_viewdata.class);
                startActivity(intent);
            }
        });
    }

    public void insert(String str_type, String dimen, String str_feature, String price, String note) {
        ContentValues value = new ContentValues();

        value.put(DatabaseHelper.str_type, str_type);
        value.put(DatabaseHelper.str_feature, str_feature);
        value.put(DatabaseHelper.dimension, dimen);
        value.put(DatabaseHelper.m_price, price);
        value.put(DatabaseHelper.note, note);

        long id = db.insert(DatabaseHelper.Table_Rental, null, value);
    }
}
