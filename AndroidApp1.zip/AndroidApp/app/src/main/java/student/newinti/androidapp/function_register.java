package student.newinti.androidapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class function_register extends AppCompatActivity {

    SQLiteOpenHelper database;
    SQLiteDatabase db;
    Button btnRegister, btnLogin;
    EditText txtUsername, txtEmail, txtPassword, txtMobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_function_register);

        database = new DatabaseHelper(this);

        txtUsername = (EditText) findViewById(R.id.txtUsername);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
        txtMobile = (EditText) findViewById(R.id.txtMobile);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLogin = (Button) findViewById(R.id.btnLogin);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db = database.getWritableDatabase();
                String username = txtUsername.getText().toString();
                String email = txtEmail.getText().toString();
                String pw = txtPassword.getText().toString();
                String mobile = txtMobile.getText().toString();

                if (username.matches("") && email.matches("") && pw.matches("") && mobile.matches("")) {
                    Toast.makeText(getApplicationContext(), "Fail To Register, Please Enter All Fields", Toast.LENGTH_LONG).show();
                } else {
                    insert(username, email, pw, mobile);
                    Toast.makeText(getApplicationContext(), "Your Account is Registered Successfully", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
        public void insert(String username, String email, String pw, String mobile) {
            ContentValues value = new ContentValues();
            value.put(DatabaseHelper.COL_2, username);
            value.put(DatabaseHelper.COL_3, email);
            value.put(DatabaseHelper.COL_4, pw);
            value.put(DatabaseHelper.COL_5, mobile);

            long id = db.insert(DatabaseHelper.TABLE_NAME, null, value);
        }
    }

