package student.newinti.androidapp;

import android.database.Cursor;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class function_login extends AppCompatActivity {

    SQLiteOpenHelper database;
    SQLiteDatabase db;
    Button btnRegister, btnLogin;
    EditText txtEmail, txtPassword;
    Cursor auth;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        database = new DatabaseHelper(this);
        db = database.getReadableDatabase();

        txtEmail = (EditText)findViewById(R.id.txtEmail);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
        btnRegister = (Button)findViewById(R.id.btnRegister);
        btnLogin = (Button)findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = txtEmail.getText().toString();
                String pw = txtPassword.getText().toString();

                auth = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_3 + " =? AND "
                        +  DatabaseHelper.COL_4 + " =? ", new String[]{email,pw});

                if (auth != null) {
                    if (auth.getCount() > 0) {
                        Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(function_login.this, function_rent.class);
                        startActivity(intent);
                    } else{
                        Toast.makeText(getApplicationContext(), "Fail To Login", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(function_login.this, function_register.class);
                startActivity(intent);
            }
        });
    }
}
