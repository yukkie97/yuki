package student.newinti.androidapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "assignment.db";
    public static final String TABLE_NAME = "user";
    public static final String Table_Rental = "rental";

    public static final String COL_1 = "ID";
    public static final String COL_2 = "UserName";
    public static final String COL_3 = "Email";
    public static final String COL_4 = "Password";
    public static final String COL_5 = "Mobile";


    public static final String str_type = "str_type";
    public static final String dimension = "dimension";
    public static final String str_feature = "str_feature";
    public static final String m_price = "m_price";
    public static final String note = "note";
    public static final String rpt_name = "rpt_name";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,UserName TEXT,Email TEXT,Password TEXT,Mobile TEXT)");
        db.execSQL("CREATE TABLE " + Table_Rental + "(Rent_ID INTEGER PRIMARY KEY AUTOINCREMENT,str_type TEXT,dimension TEXT,str_feature TEXT,m_price TEXT, note TEXT, rpt_name TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Table_Rental);
        onCreate(db);
    }

    public Cursor viewRentedData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + Table_Rental;
        Cursor result = db.rawQuery(query, null);

        return result;
    }
}
